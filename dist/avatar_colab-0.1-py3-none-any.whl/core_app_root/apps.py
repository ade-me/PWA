from django.apps import AppConfig


class CoreAppRootConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_app_root'
    label='core_app_root'
